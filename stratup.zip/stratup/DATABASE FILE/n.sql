SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

---
--- Database: `supplements`
---

-- ------------------------------------------------------

--
-- Table structure for table `physiotherapy_supplements`
--

CREATE TABLE physiotherapy_supplements (
   `Supplements` VARCHAR(255) NOT NULL,
   `Quantity` INT NOT NULL,
   `Price` DECIMAL(10,2) NOT NULL,
   `Brand` VARCHAR(255) NOT NULL,
   `PRIMARY KEY (Supplements)
UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `physiotherapy_supplements`
--

INSERT INTO `physiotherapy_supplements` (`Supplements`, `Quantity`, `Price`, `Brand`)
VALUES 
('Iontophoresis', 5, 25.99, 'Compex'),
('Low Intensity Pulsed Ultrasound', 10, 64.99, 'Omron'),
('Ultrasound Therapy', 8, 45.99, 'Compex'),
('Laser Therapy', 15, 89.99, 'Omron');

-- ---------------------------------------------------------

--
-- Table structure for table `nutrition_supplements`
--

CREATE TABLE `nutrition_supplements` (
   `Supplements` VARCHAR(255) NOT NULL,
   `Quantity` INT NOT NULL,
   `Price` DECIMAL(10,2) NOT NULL,
   PRIMARY KEY (`Supplements`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nutrition_supplements`
--

INSERT INTO `nutrition_supplements` (`Supplements`, `Quantity`, `Price`)
VALUES 
('Protein Powder', 20, 39.99),
('Multivitamin', 30, 19.99),
('Fish Oil', 50, 12.99),
('Creatine Monohydrate', 10, 29.99);


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;