<!DOCTYPE html>
<html>
<head>
	<title>Supplements Page</title>
	<style>
			body {
			background-image: url("WhatsApp Image 2023-06-20 at 10.46.13 PM.jpeg");
			background-size: cover;
			background-position: center;
            background-repeat: no-repeat;
            padding: 60px;
            max-width: 1000px;
            margin: 120px auto;
			font-family: Arial, sans-serif;
		}
		h1 {
			text-align: center;
			margin-top: 30px;
            width: 100%;
            display: flex;
            justify-content: center;
            white-space: nowrap;

		}
		button {
			display: block;
			margin: 60px auto;
			padding: 10px 20px;
			border: none;
			border-radius: 5px;
			background-color: #4CAF50;
			color: #fff;
			font-size: 18px;
			cursor: pointer;
            white-space: nowrap;

		}
		button:hover {
			background-color: #3e8e41;
		}
	</style>
</head>
<body>
	<h1>Choose Supplement Category</h1>
	<button id="physioBtn">Physiotherapy Supplements</button>
	<button id="nutritionBtn">Nutrition Supplements</button>

	<script>
		const physioBtn = document.getElementById("physioBtn");
		const nutritionBtn = document.getElementById("nutritionBtn");

		physioBtn.addEventListener("click", () => {
			window.location.href = "physiotherapy.php"; // Redirect to the physiotherapy page
		});

		nutritionBtn.addEventListener("click", () => {
			window.location.href = "nutrition.php"; // Redirect to the nutrition page
		});
	</script>
</body>
</html>