<?php
// Establish a connection to the MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supplements";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Execute a query to retrieve the data
$sql = "SELECT * FROM physiotherapy";
if(isset($_GET['search'])) {
  $search = mysqli_real_escape_string($conn, $_GET['search']);
  $sql .= " WHERE supplements LIKE '%$search%' OR quantity LIKE '%$search%' OR price LIKE '%$search%'";
}
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<style>
  body {
 background-image: url("WhatsApp Image 2023-06-20 at 10.46.13 PM.jpeg");
 background-size: cover;
 background-position: center;
 background-repeat: no-repeat;
 padding: 6%;
 font-family: Arial, sans-serif;
 backdrop-filter: blur(5px); /* Add the backdrop-filter property with the blur value */
   }
   table {
     border-collapse: collapse;
     width: 100%;
   }
   /*Edit button style*/
   button.edit {
    background-color: rgb(74, 52, 6);
    color: white; /* add this rule to change the font color to white */
    border: none; /* add this rule to remove the border */
    padding: 10px; /* add this rule to increase the padding */
    border-radius: 5px; /* add this rule to add rounded corners */
    cursor: pointer; /* add this rule to change the cursor to a pointer */
   }

   /* Style the table header */
   th {
     background-color: #ddd;
     font-weight: bold;
     text-align: left;
     padding: 8px;
   }
   /*Add Supplement Button Style*/
   #add-supplement-btn {
   background-color: rgb(205, 204, 225);
   color: rgba(0, 0, 0, 0.937);
   padding: 10px 20px;
   border-radius: 5px;
   border: none;
   cursor: pointer;
 }

 #add-supplement-btn:hover {
   background-color: rgb(255, 255, 255);
 }

 #logout-btn {
    background-color: rgb(69, 147, 94);
    color: rgba(0, 0, 0, 0.937);
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
    
  }

  #logout-btn:hover {
    background-color: rgb(44, 232, 135);
  }

  #Return-Supplement-Page-btn{
    background-color: rgb(69, 147, 94);
    color: rgba(0, 0, 0, 0.937);
    padding: 10px 20px;
    border-radius: 5px;
    border: none;
    cursor: pointer;
    
  }

  #Return-Supplement-Page-btn:hover {
    background-color: rgb(44, 232, 135);
  }


   /* Style the table cells */
   td, th {
     border: 1px solid #ddd;
     padding: 4px;
   }

   /* Style the list */
   ul {
     list-style-type: none;
     margin: 0;
     padding: 0;
   }

   /* Style the list items */
   li {
     margin: 5px 0;
     padding-left: 20px;
     position: relative;
   }

   /* Style the list item markers */
   li:before {
     content: "•";
     position: absolute;
     left: 0;
   }

   /* Style the search bar */
   #search-bar {
     float: left;
     margin-bottom: 10px;
   }

   /* Style the error message */
   .error {
     color: red;
   }
   
   /* Style the container */
   .container {
     display: flex;
     flex-wrap: wrap;
   }
   
   /* Style the content sections */
   .tab-content {
     width: 50%;
     padding: 20px;
     box-sizing: border-box;
   }
   
   /* Style the request content table buttons */
   .accept-btn {
       background-color: #32CD32; /* green */
       color: #fff;
       padding: 10px;
       border: none;
       border-radius: 5px;
       cursor: pointer;
       margin-right: 20px;
     }
     .accept-btn:hover {
       background-color: #228B22;
     }

     /* Styles for the reject button */
     .reject-btn {
       background-color: #FF0000; /* red */
       color: #fff;
       padding: 10px;
       border: none;
       border-radius: 5px;
       cursor: pointer;
     }
     .reject-btn:hover {
       background-color: #B22222;
     }
</style>
  <head>
    <title>Lists Content</title>
  </head>
  <body>
    <div class="container">
      <div class="tab-content">
        <h2>Lists Content</h2>
        <form method="GET">
          <input type="text" id="search-bar" name="search" placeholder="Search..." onkeydown="searchTable(event)" value="<?php if(isset($_GET['search'])) echo $_GET['search']; ?>">
          <button type="submit">Search</button>
        </form>
        <table id="list-content-table">
          <thead>
            <tr>
              <th>Supplements</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Brand</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // Loop through the result set and display the data in the table
            if (mysqli_num_rows($result) > 0) {
              while($row = mysqli_fetch_assoc($result)) {
                echo "<tr data-quantity='" . $row["quantity"] . "'>";
                echo "<td>" . $row["supplements"] . "</td>";
                echo "<td><input type='text' value='" . $row["quantity"] . "'></td>";
                echo "<td>" . $row["price"] . " EGP" . "</td>";
                echo "<td>" . $row["brand"] . "</td>";
                echo "<td>";
                echo "<button class='edit' onclick='editRow(" . $row["quantity"] . ")'>Edit</button>";
                echo "</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='4'>No supplements found.</td></tr>";
            }
            ?>
          </tbody>
        </table>
        <br>
        <button id="add-supplement-btn" onclick="addRow()">Add Supplement</button>
        <br>
        <br>
        <button id="logout-btn" onclick="logout()">Logout</button>
        <br>
        <br>
        <button id="Return-Supplement-Page-btn" onclick="ReturnSupplementPage()">ReturnSupplementPage</button>
      </div>
      <div id="request" class="tab-content">
        <h2>Requests Content</h2>
        <input type="text" id="search-bar" placeholder="Search..." onkeydown="searchTable(event)">
        <table id="request-content-table">
          <thead>
          <tr>
            <th>Supplements</th>
            <th>Quantity</th>           
            <th>Brand</th>
            <th>Hospital</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Iontophoresis</td>
            <td>2</td>
            <td>Compex</td>
            <td>Hospital A</td>
            <td>
              <button class="accept-btn" onclick="acceptRequest(1)">Accept</button>
              <button class="reject-btn" onclick="rejectRequest(1)">Reject</button>
            </td>
          </tr>
          <tr>
            <td>Low Intensity Pulsed Ultrasound</td>
            <td>5</td>
            <td>Omron</td>
            <td>Hospital B</td>
            <td>
              <button class="accept-btn" onclick="acceptRequest(2)">Accept</button>
              <button class="reject-btn" onclick="rejectRequest(2)">Reject</button>
            </td>
          </tr>
          <tr>
            <td>Ultrasound Therapy</td>
            <td>2</td>
            <td>Compex</td>
            <td>Hospital C</td>
            <td>
              <button class="accept-btn" onclick="acceptRequest(3)">Accept</button>
              <button class="reject-btn" onclick="rejectRequest(3)">Reject</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

    <!-- Add jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
      function editRow(quantity) {
        // Get the row element
        var row = $("tr[data-quantity='" + quantity + "']");

        // Get the input element
        var input = row.find("input[type='text']");

        // Save the original quantity
        var originalQuantity = quantity;

        // Disable editing of the other rows
        $("input[type='text']").prop("disabled", true);

        // Enable editing of the current row
        input.prop("disabled", false);

        // Set focus on the input field
        input.focus();

        // Handle the input field blur event
        input.on("blur", function() {
          // Get the new quantity
          var newQuantity = parseInt(input.val());

          // Check if the input is a valid number
          if (isNaN(newQuantity) || newQuantity < 0) {
            alert("Please enter a valid quantity.");
            input.val(originalQuantity);
            return;
          }

          // Check if the quantity is zero
          if (newQuantity === 0) {
            input.val("Not Available");
          }

          // Update the quantity in the database
          $.post("update.php", {quantity: newQuantity, id: row.data("id")}, function(data) {
            // Update the row data
            row.data("quantity", newQuantity);

            // Disable editing of the input field
            input.prop("disabled", true);

            // Enable editing of the other rows
            $("input[type='text']").prop("disabled", false);
          });
        });
      }

      function addRow() {
        // Create a new row
        var row = $("<tr>");

        // Add the supplement column
        var supplementColumn = $("<td>");
        var supplementInput = $("<input type='text' placeholder='Supplement Name'>");
        supplementColumn.append(supplementInput);
        row.append(supplementColumn);

        // Add the quantity column
        var quantityColumn = $("<td>");
        var quantityInput = $("<input type='text' placeholder='Quantity'>");
        quantityColumn.append(quantityInput);
        row.append(quantityColumn);

        // Add the price column
        var priceColumn = $("<td>");
        var priceInput = $("<input type='text' placeholder='Price'>");
        priceColumn.append(priceInput);
        row.append(priceColumn);

        // Add the action column
        var actionColumn = $("<td>");
        var saveButton = $("<button>Save</button>");
        saveButton.on("click", function() {
          // Get the supplement name, quantity, and price
          var supplement = supplementInput.val();
          var quantity = parseInt(quantityInput.val());
          var price = parseFloat(priceInput.val());

          // Check if the inputs are valid
          if (supplement === "" || isNaN(quantity) || isNaN(price) || quantity < 0 || price < 0) {
            alert("Please enter valid data.");
            return;
          }

          // Check if the quantity is zero
          if (quantity === 0) {
            quantityInput.val("Not Available");
          }

          // Add the new supplement to the database
          $.post("add.php", {supplement: supplement, quantity: quantity, price: price}, function(data) {
            // Reload the page
            location.reload();
          });
        });
        actionColumn.append(saveButton);
        row.append(actionColumn);

        // Append the new row to the table
        $("#list-content-table tbody").append(row);
      }

      function logout() {
        // Redirect to the login page
        window.location.href = "index.php";
      }

      function ReturnSupplementPage() {
        // Redirect to the supplement page
        window.location.href = "SupplementsPage.php";
      }

      function searchTable(event) {
        // Get the search query
        var searchQuery = $("#search-bar").val().toLowerCase();

        // Loop through the rows of the table
        $("#list-content-table tbody tr").each(function() {
          // Get the text of the supplements and quantity columns
          var supplements = $(this).find("td:nth-child(1)").text().toLowerCase();
          var quantity = $(this).find("td:nth-child(2)").text().toLowerCase();

          // Hide the row if it doesn't match the search query
          if (supplements.indexOf(searchQuery) === -1 && quantity.indexOf(searchQuery) === -1) {
            $(this).hide();
          } else {
            $(this).show();
          }
        });
      }
    </script>
  </body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>