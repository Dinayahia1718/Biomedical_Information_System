<!DOCTYPE html>
<html>
<head>
	<title>Supplement Login</title>
	<style>
		body {
			background-image: url("physical-therapy-nutrition.jpg");
			background-size: cover;
			background-position: center;
            background-repeat: no-repeat;
            padding: 102px;
			font-family: Arial, sans-serif;
            backdrop-filter: blur(4px); /* Add the backdrop-filter property with the blur value */
		}
		form {
			background-color: rgba(245, 245, 245, 0);
			padding: 20px;
			margin: 90px auto;
			max-width: 400px;
		}
		input[type="text"], input[type="password"] {
			padding: 10px;
			margin: 10px 0;
			width: 100%;
			border: none;
            border-bottom: 1px solid #ccc;
			font-size: 16px;
		}
        input[type="submit"] {
			background-color: #3b378e;
			color: white;
			padding: 10px 20px;
			border: none;
			cursor: pointer;
			font-size: 16px;
		}
		input[type="submit"]:hover {
			background-color: #420fec;
		}
	</style>
</head>
<body>
    <h1>Welcome to Supplements Login</h1>
    <div class="container">
    <form action ="connect.php" method = "post">
    <div>
    <label for="username">Username</label>
	<input type="text" id="username" name="username" required>
	<label for="password">Password</label>
	<input type="password" id="password" name="password" required>
	<input type="submit" value="Login">
    </div>
    <footer>
        <p>&copy; 2023 Supplement Login. All rights reserved.</p>
    </footer>
	</form>
</body>
</html>