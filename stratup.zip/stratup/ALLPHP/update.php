<?php
// Establish a connection to the MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supplements";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get the quantity and id from the post data
$quantity = mysqli_real_escape_string($conn, $_POST['quantity']);

// Execute a query to update the quantity in the database
$sql = "UPDATE nutrition SET quantity='$quantity'";
if (mysqli_query($conn, $sql)) {
  echo "Quantity updated successfully.";
} else {
  echo "Error updating quantity: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>