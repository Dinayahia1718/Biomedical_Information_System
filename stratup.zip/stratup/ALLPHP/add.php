<?php
// Establish a connection to the MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supplements";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check the connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get the supplement name, quantity, and price from the post data
$supplement = mysqli_real_escape_string($conn, $_POST['supplement']);
$quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
$price = mysqli_real_escape_string($conn, $_POST['price']);

// Execute a query to insert the new supplement into the database
$sql = "INSERT INTO nutrition (supplements, quantity, price) VALUES ('$supplement', '$quantity', '$price')";
if (mysqli_query($conn, $sql)) {
  echo "New supplement added successfully.";
} else {
  echo "Error adding supplement: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);
?>