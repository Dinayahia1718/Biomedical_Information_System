<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supplements";

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Create a new MySQLi object and check for connection errors
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Construct the SQL query to retrieve the user with the specified username and password
    $sql = "SELECT * FROM `data` WHERE username='$username' AND password='$password'";
    $result = $conn->query($sql);

    // Check if the query returned any rows
    if ($result->num_rows > 0) {
        // Valid username and password, redirect to the supplements page
        header("Location: SupplementsPage.php");
        exit();
    } else {
        // Invalid username or password, show an error message
        echo "<script>alert('Invalid username or password. Please try again.');</script>";
    }

    // Close the MySQLi connection
    $conn->close();
}
?>